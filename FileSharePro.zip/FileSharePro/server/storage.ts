import {
  users,
  files,
  activityLogs,
  sharedFiles,
  type User,
  type UpsertUser,
  type File,
  type InsertFile,
  type ActivityLog,
  type InsertActivityLog,
  type SharedFile,
  type InsertSharedFile,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import fs from "fs";
import path from "path";
import { promisify } from "util";

const mkdir = promisify(fs.mkdir);
const unlink = promisify(fs.unlink);
const uploadDir = path.join(process.cwd(), "uploads");

// Make sure upload directory exists
try {
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
} catch (error) {
  console.error("Error creating uploads directory:", error);
}

// Interface for storage operations
export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Additional user operations
  getAllUsers(): Promise<User[]>;
  getUserStorageStats(userId: string): Promise<{ used: number; limit: number }>;
  updateUserStorageUsed(userId: string, sizeChange: number): Promise<void>;
  
  // File operations
  createFile(userId: string, fileData: InsertFile): Promise<File>;
  getFile(fileId: number): Promise<File | undefined>;
  getUserFiles(userId: string): Promise<File[]>;
  getRecentFiles(userId: string, limit?: number): Promise<File[]>;
  deleteFile(fileId: number): Promise<boolean>;
  
  // Activity log operations
  logActivity(logData: InsertActivityLog): Promise<ActivityLog>;
  getUserActivities(userId: string, limit?: number): Promise<ActivityLog[]>;
  getAllActivities(limit?: number): Promise<ActivityLog[]>;
  
  // Shared files operations
  shareFile(shareData: InsertSharedFile): Promise<SharedFile>;
  getSharedFiles(userId: string): Promise<File[]>;
  unshareFile(fileId: number, sharedWithUserId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Additional user operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.createdAt);
  }

  async getUserStorageStats(userId: string): Promise<{ used: number; limit: number }> {
    const [user] = await db
      .select({
        used: users.storageUsed,
        limit: users.storageLimit,
      })
      .from(users)
      .where(eq(users.id, userId));
    
    return user || { used: 0, limit: 104857600 }; // Default to 100MB
  }

  async updateUserStorageUsed(userId: string, sizeChange: number): Promise<void> {
    await db
      .update(users)
      .set({
        storageUsed: sql`${users.storageUsed} + ${sizeChange}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  // File operations
  async createFile(userId: string, fileData: InsertFile): Promise<File> {
    // Create user directory if it doesn't exist
    const userDir = path.join(uploadDir, userId);
    if (!fs.existsSync(userDir)) {
      await mkdir(userDir, { recursive: true });
    }

    const [file] = await db
      .insert(files)
      .values({
        ...fileData,
        userId,
      })
      .returning();
    
    // Update user's storage used
    await this.updateUserStorageUsed(userId, fileData.size);
    
    return file;
  }

  async getFile(fileId: number): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, fileId));
    return file;
  }

  async getUserFiles(userId: string): Promise<File[]> {
    return await db
      .select()
      .from(files)
      .where(eq(files.userId, userId))
      .orderBy(desc(files.createdAt));
  }

  async getRecentFiles(userId: string, limit = 5): Promise<File[]> {
    return await db
      .select()
      .from(files)
      .where(eq(files.userId, userId))
      .orderBy(desc(files.createdAt))
      .limit(limit);
  }

  async deleteFile(fileId: number): Promise<boolean> {
    try {
      const [file] = await db
        .select()
        .from(files)
        .where(eq(files.id, fileId));
      
      if (!file) return false;
      
      // Delete the file from filesystem
      const filePath = file.path;
      if (fs.existsSync(filePath)) {
        await unlink(filePath);
      }
      
      // Update user's storage
      await this.updateUserStorageUsed(file.userId, -file.size);
      
      // Delete file record
      await db.delete(files).where(eq(files.id, fileId));
      
      return true;
    } catch (error) {
      console.error("Error deleting file:", error);
      return false;
    }
  }

  // Activity log operations
  async logActivity(logData: InsertActivityLog): Promise<ActivityLog> {
    const [log] = await db
      .insert(activityLogs)
      .values(logData)
      .returning();
    
    return log;
  }

  async getUserActivities(userId: string, limit = 10): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.userId, userId))
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  async getAllActivities(limit = 20): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  // Shared files operations
  async shareFile(shareData: InsertSharedFile): Promise<SharedFile> {
    const [shared] = await db
      .insert(sharedFiles)
      .values(shareData)
      .returning();
    
    return shared;
  }

  async getSharedFiles(userId: string): Promise<File[]> {
    return await db
      .select({
        ...files
      })
      .from(files)
      .innerJoin(
        sharedFiles,
        eq(files.id, sharedFiles.fileId)
      )
      .where(eq(sharedFiles.sharedWithUserId, userId))
      .orderBy(desc(files.createdAt));
  }

  async unshareFile(fileId: number, sharedWithUserId: string): Promise<boolean> {
    try {
      await db
        .delete(sharedFiles)
        .where(
          and(
            eq(sharedFiles.fileId, fileId),
            eq(sharedFiles.sharedWithUserId, sharedWithUserId)
          )
        );
      
      return true;
    } catch (error) {
      console.error("Error unsharing file:", error);
      return false;
    }
  }
}

export const storage = new DatabaseStorage();
