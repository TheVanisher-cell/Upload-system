import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { insertFileSchema, insertActivityLogSchema, insertSharedFileSchema } from "@shared/schema";
import { z } from "zod";

// Setup multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");

// Make sure upload directory exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage2 = multer.diskStorage({
  destination: function (req, file, cb) {
    const userId = (req as any).user.claims.sub;
    const userDir = path.join(uploadDir, userId);
    
    // Create user directory if it doesn't exist
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }
    
    cb(null, userDir);
  },
  filename: function (req, file, cb) {
    // Generate unique filename
    const uniqueName = `${Date.now()}-${randomUUID()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage: storage2,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
  fileFilter: function (req, file, cb) {
    // Optional: Add file type restrictions here if needed
    cb(null, true);
  }
});

// Helper function for checking admin role
function isAdmin(req: Request, res: Response, next: Function) {
  const userId = (req as any).user.claims.sub;
  
  // First check if user is authenticated
  isAuthenticated(req, res, async () => {
    try {
      const user = await storage.getUser(userId);
      
      if (user && user.role === 'admin') {
        return next();
      }
      
      return res.status(403).json({ message: "Forbidden: Admin access required" });
    } catch (error) {
      console.error("Error checking admin role:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // File routes
  app.post('/api/files/upload', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const userId = req.user.claims.sub;
      
      // Get user storage stats
      const { used, limit } = await storage.getUserStorageStats(userId);
      
      // Check if user has enough storage
      if (used + file.size > limit) {
        // Delete the uploaded file since we're rejecting it
        fs.unlinkSync(file.path);
        return res.status(400).json({ message: "Storage limit exceeded" });
      }

      // Validate file data
      const fileData = insertFileSchema.parse({
        name: path.basename(file.path),
        originalName: file.originalname,
        size: file.size,
        mimeType: file.mimetype,
        path: file.path,
        isPublic: false,
      });

      // Save file to database
      const savedFile = await storage.createFile(userId, fileData);
      
      // Log activity
      await storage.logActivity({
        userId,
        fileId: savedFile.id,
        action: "upload",
        details: `Uploaded ${file.originalname} (${file.size} bytes)`
      });

      res.status(201).json(savedFile);
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  app.get('/api/files', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const files = await storage.getUserFiles(userId);
      res.json(files);
    } catch (error) {
      console.error("Error fetching files:", error);
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.get('/api/files/recent', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const files = await storage.getRecentFiles(userId, limit);
      res.json(files);
    } catch (error) {
      console.error("Error fetching recent files:", error);
      res.status(500).json({ message: "Failed to fetch recent files" });
    }
  });

  app.get('/api/files/shared', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sharedFiles = await storage.getSharedFiles(userId);
      res.json(sharedFiles);
    } catch (error) {
      console.error("Error fetching shared files:", error);
      res.status(500).json({ message: "Failed to fetch shared files" });
    }
  });

  app.get('/api/files/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const fileId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Get file
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // Check if user owns the file or file is shared with them
      if (file.userId !== userId) {
        // Check if file is shared with this user
        const sharedFiles = await storage.getSharedFiles(userId);
        const isShared = sharedFiles.some(sf => sf.id === fileId);
        
        if (!isShared && !file.isPublic) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      // Log activity
      await storage.logActivity({
        userId,
        fileId,
        action: "download",
        details: `Downloaded ${file.originalName}`
      });
      
      // Send file
      res.download(file.path, file.originalName);
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  app.delete('/api/files/:id', isAuthenticated, async (req: any, res) => {
    try {
      const fileId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Get file
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // Check if user owns the file
      if (file.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Delete file
      const deleted = await storage.deleteFile(fileId);
      
      if (deleted) {
        // Log activity
        await storage.logActivity({
          userId,
          fileId: null, // File is deleted, so no fileId
          action: "delete",
          details: `Deleted ${file.originalName}`
        });
        
        return res.status(200).json({ message: "File deleted successfully" });
      } else {
        return res.status(500).json({ message: "Failed to delete file" });
      }
    } catch (error) {
      console.error("Error deleting file:", error);
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // File sharing
  app.post('/api/files/:id/share', isAuthenticated, async (req: any, res) => {
    try {
      const fileId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Validate request
      const shareSchema = z.object({
        sharedWithUserId: z.string(),
      });
      
      const { sharedWithUserId } = shareSchema.parse(req.body);
      
      // Get file
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // Check if user owns the file
      if (file.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Check if user exists
      const sharedWithUser = await storage.getUser(sharedWithUserId);
      
      if (!sharedWithUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Share file
      const shareData = insertSharedFileSchema.parse({
        fileId,
        sharedByUserId: userId,
        sharedWithUserId,
      });
      
      await storage.shareFile(shareData);
      
      // Log activity
      await storage.logActivity({
        userId,
        fileId,
        action: "share",
        details: `Shared ${file.originalName} with ${sharedWithUser.email || sharedWithUser.id}`
      });
      
      res.status(200).json({ message: "File shared successfully" });
    } catch (error) {
      console.error("Error sharing file:", error);
      res.status(500).json({ message: "Failed to share file" });
    }
  });

  app.delete('/api/files/:id/share/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const fileId = parseInt(req.params.id);
      const sharedWithUserId = req.params.userId;
      const userId = req.user.claims.sub;
      
      // Get file
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // Check if user owns the file
      if (file.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Unshare file
      const unshared = await storage.unshareFile(fileId, sharedWithUserId);
      
      if (unshared) {
        // Log activity
        await storage.logActivity({
          userId,
          fileId,
          action: "unshare",
          details: `Unshared ${file.originalName}`
        });
        
        return res.status(200).json({ message: "File unshared successfully" });
      } else {
        return res.status(500).json({ message: "Failed to unshare file" });
      }
    } catch (error) {
      console.error("Error unsharing file:", error);
      res.status(500).json({ message: "Failed to unshare file" });
    }
  });

  // Activity routes
  app.get('/api/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activities = await storage.getUserActivities(userId, limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Storage stats
  app.get('/api/storage', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStorageStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching storage stats:", error);
      res.status(500).json({ message: "Failed to fetch storage stats" });
    }
  });

  // Admin routes
  app.get('/api/admin/users', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching all users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/activities', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const activities = await storage.getAllActivities(limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching all activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  app.post('/api/admin/user/:id/make-admin', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update user role
      const updatedUser = await storage.upsertUser({
        ...user,
        role: "admin"
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error making user admin:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  app.post('/api/admin/user/:id/storage-limit', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate request
      const schema = z.object({
        storageLimit: z.number().min(0)
      });
      
      const { storageLimit } = schema.parse(req.body);
      
      // Update user storage limit
      const updatedUser = await storage.upsertUser({
        ...user,
        storageLimit
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating storage limit:", error);
      res.status(500).json({ message: "Failed to update storage limit" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
