import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format bytes to a human-readable format
 * @param bytes - The number of bytes
 * @param decimals - Number of decimal places to include
 * @returns Formatted string (e.g. "2.5 MB")
 */
export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Get file type icon or color class based on mime type
 * @param mimeType - The MIME type of the file
 * @returns Object with icon and color classes
 */
export function getFileTypeInfo(mimeType: string) {
  // Default values
  let iconClass = 'file-text';
  let colorClass = 'text-blue-600 bg-blue-100';
  
  if (!mimeType) return { iconClass, colorClass };

  // Check mime type categories
  if (mimeType.startsWith('image/')) {
    iconClass = 'image';
    colorClass = 'text-purple-600 bg-purple-100';
  } else if (mimeType.startsWith('video/')) {
    iconClass = 'video';
    colorClass = 'text-pink-600 bg-pink-100';
  } else if (mimeType.startsWith('audio/')) {
    iconClass = 'music';
    colorClass = 'text-indigo-600 bg-indigo-100';
  } else if (mimeType.includes('pdf')) {
    iconClass = 'file-text';
    colorClass = 'text-red-600 bg-red-100';
  } else if (mimeType.includes('spreadsheet') || mimeType.includes('excel') || mimeType.includes('csv')) {
    iconClass = 'file-spreadsheet';
    colorClass = 'text-green-600 bg-green-100';
  } else if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) {
    iconClass = 'file-presentation';
    colorClass = 'text-orange-600 bg-orange-100';
  } else if (mimeType.includes('document') || mimeType.includes('word')) {
    iconClass = 'file-text';
    colorClass = 'text-blue-600 bg-blue-100';
  } else if (mimeType.includes('archive') || mimeType.includes('zip') || mimeType.includes('compressed')) {
    iconClass = 'archive';
    colorClass = 'text-yellow-600 bg-yellow-100';
  }
  
  return { iconClass, colorClass };
}

/**
 * Truncate text with ellipsis
 * @param text - The text to truncate
 * @param length - Maximum length before truncation
 * @returns Truncated text
 */
export function truncateText(text: string, length = 30): string {
  if (!text || text.length <= length) return text;
  return text.substring(0, length) + '...';
}
