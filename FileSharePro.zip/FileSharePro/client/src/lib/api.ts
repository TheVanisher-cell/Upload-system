import { apiRequest } from "./queryClient";

// File functions
export async function uploadFile(fileData: FormData) {
  const response = await fetch('/api/files/upload', {
    method: 'POST',
    body: fileData,
    credentials: 'include',
  });
  
  if (!response.ok) {
    throw new Error('Failed to upload file');
  }
  
  return response.json();
}

export async function deleteFile(fileId: number) {
  return apiRequest('DELETE', `/api/files/${fileId}`);
}

export async function shareFile(fileId: number, userId: string) {
  return apiRequest('POST', `/api/files/${fileId}/share`, { sharedWithUserId: userId });
}

export async function unshareFile(fileId: number, userId: string) {
  return apiRequest('DELETE', `/api/files/${fileId}/share/${userId}`);
}

// Admin functions
export async function makeUserAdmin(userId: string) {
  return apiRequest('POST', `/api/admin/user/${userId}/make-admin`);
}

export async function updateUserStorageLimit(userId: string, storageLimit: number) {
  return apiRequest('POST', `/api/admin/user/${userId}/storage-limit`, { storageLimit });
}
