import { useState, useRef, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { UploadCloud, X, File } from "lucide-react";
import { formatBytes } from "@/lib/utils";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";

interface FileUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function FileUploadModal({ isOpen, onClose }: FileUploadModalProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const xhr = new XMLHttpRequest();
      
      // Create a promise to handle the XHR response
      return new Promise((resolve, reject) => {
        xhr.open("POST", "/api/files/upload");
        
        // Track upload progress
        xhr.upload.addEventListener("progress", (event) => {
          if (event.lengthComputable) {
            const file = formData.get("file") as File;
            const percentComplete = Math.round((event.loaded / event.total) * 100);
            setUploadProgress(prev => ({
              ...prev,
              [file.name]: percentComplete
            }));
          }
        });
        
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(JSON.parse(xhr.responseText));
          } else {
            reject(new Error(xhr.statusText || "Upload failed"));
          }
        };
        
        xhr.onerror = () => reject(new Error("Network error"));
        
        xhr.send(formData);
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      queryClient.invalidateQueries({ queryKey: ["/api/files/recent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/storage"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    },
    onError: (error: any) => {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error.message || "An error occurred during upload",
        variant: "destructive"
      });
    }
  });

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      // Small delay to allow the closing animation to complete
      const timeout = setTimeout(() => {
        setFiles([]);
        setUploading(false);
        setUploadProgress({});
      }, 300);
      
      return () => clearTimeout(timeout);
    }
  }, [isOpen]);

  // Set up drag and drop event listeners
  useEffect(() => {
    const dropArea = dropAreaRef.current;
    
    if (!dropArea) return;
    
    const highlight = () => {
      dropArea.classList.add("border-primary", "bg-blue-50");
      dropArea.classList.remove("border-gray-300", "bg-white");
    };
    
    const unhighlight = () => {
      dropArea.classList.remove("border-primary", "bg-blue-50");
      dropArea.classList.add("border-gray-300", "bg-white");
    };
    
    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      unhighlight();
      
      if (e.dataTransfer?.files) {
        handleFiles(Array.from(e.dataTransfer.files));
      }
    };
    
    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      highlight();
    };
    
    const handleDragLeave = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      unhighlight();
    };
    
    dropArea.addEventListener("drop", handleDrop);
    dropArea.addEventListener("dragover", handleDragOver);
    dropArea.addEventListener("dragleave", handleDragLeave);
    
    return () => {
      dropArea.removeEventListener("drop", handleDrop);
      dropArea.removeEventListener("dragover", handleDragOver);
      dropArea.removeEventListener("dragleave", handleDragLeave);
    };
  }, [isOpen]);

  // Handle file selection
  const handleFiles = (selectedFiles: File[]) => {
    // Check file size limit (100MB)
    const validFiles = selectedFiles.filter(file => file.size <= 100 * 1024 * 1024);
    
    if (validFiles.length < selectedFiles.length) {
      toast({
        title: "File size exceeded",
        description: "Some files were not added because they exceed the 100MB limit",
        variant: "destructive"
      });
    }
    
    setFiles(prev => [...prev, ...validFiles]);
  };

  // Handle browse button click
  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(Array.from(e.target.files));
    }
  };

  // Remove a file from the list
  const removeFile = (fileName: string) => {
    setFiles(files.filter(file => file.name !== fileName));
    setUploadProgress(prev => {
      const newProgress = { ...prev };
      delete newProgress[fileName];
      return newProgress;
    });
  };

  // Handle upload click
  const handleUpload = async () => {
    if (files.length === 0) return;
    
    setUploading(true);
    
    try {
      // Upload each file individually
      for (const file of files) {
        const formData = new FormData();
        formData.append("file", file);
        
        await uploadMutation.mutateAsync(formData);
      }
      
      toast({
        title: "Upload complete",
        description: `Successfully uploaded ${files.length} file${files.length !== 1 ? 's' : ''}`,
      });
      
      onClose();
    } catch (error) {
      // Error handling is done in the mutation
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Upload Files</DialogTitle>
          <DialogDescription>
            Upload files to your cloud storage. Maximum file size is 100MB.
          </DialogDescription>
        </DialogHeader>
        
        <div 
          ref={dropAreaRef}
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-4 transition-colors"
        >
          <div className="flex flex-col items-center">
            <UploadCloud className="h-12 w-12 text-gray-400 mb-3" />
            <p className="text-gray-700 mb-2">Drag and drop files here</p>
            <p className="text-gray-500 text-sm mb-4">or</p>
            <Button onClick={handleBrowseClick}>
              Browse Files
            </Button>
            <input 
              ref={fileInputRef}
              type="file" 
              multiple 
              className="hidden" 
              onChange={handleFileInputChange}
            />
            <p className="text-xs text-gray-500 mt-4">Max file size: 100MB</p>
          </div>
        </div>
        
        {files.length > 0 && (
          <div className="space-y-3 max-h-60 overflow-y-auto">
            {files.map((file) => (
              <div key={file.name} className="flex items-center bg-gray-50 p-3 rounded-lg">
                <div className="flex-shrink-0 mr-3">
                  <File className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div 
                      className="bg-primary h-1.5 rounded-full" 
                      style={{ width: `${uploadProgress[file.name] || 0}%` }}
                    ></div>
                  </div>
                </div>
                <div className="ml-3 flex-shrink-0">
                  <span className="text-xs text-gray-500">{formatBytes(file.size)}</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="ml-2" 
                  onClick={() => removeFile(file.name)}
                  disabled={uploading}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={uploading}>
            Cancel
          </Button>
          <Button onClick={handleUpload} disabled={files.length === 0 || uploading}>
            {uploading ? "Uploading..." : "Upload"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
