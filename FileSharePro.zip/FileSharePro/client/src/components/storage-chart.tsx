import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { formatBytes } from "@/lib/utils";

interface StorageChartProps {
  used: number;
  limit: number;
  isLoading?: boolean;
}

export default function StorageChart({ used, limit, isLoading = false }: StorageChartProps) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <h2 className="text-lg font-semibold mb-4">Storage Usage</h2>
          <div className="flex items-center justify-center h-64">
            <div className="h-48 w-48 rounded-full bg-gray-200 animate-pulse"></div>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-6 bg-gray-200 animate-pulse rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const percentage = Math.min(100, Math.round((used / limit) * 100));
  
  // For the pie chart SVG
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  // Placeholder for file type distribution
  // In a real app, this would come from an API
  const fileTypes = [
    { type: "Documents", percentage: 35, color: "bg-blue-500" },
    { type: "Media", percentage: 28, color: "bg-violet-500" },
    { type: "Images", percentage: 22, color: "bg-emerald-500" },
    { type: "Other", percentage: 15, color: "bg-amber-500" },
  ];

  return (
    <Card>
      <CardContent className="pt-6">
        <h2 className="text-lg font-semibold mb-4">Storage Usage</h2>
        
        <div className="flex items-center justify-center h-64">
          <div className="relative h-48 w-48">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">{formatBytes(used)}</div>
                <div className="text-sm text-gray-500">of {formatBytes(limit)} used</div>
              </div>
            </div>
            
            {/* SVG Pie Chart */}
            <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
              {/* Background circle */}
              <circle 
                cx="50" 
                cy="50" 
                r={radius} 
                fill="transparent" 
                stroke="#EBF5FF" 
                strokeWidth="15"
              />
              {/* Progress circle */}
              <circle 
                cx="50" 
                cy="50" 
                r={radius} 
                fill="transparent" 
                stroke="hsl(var(--primary))" 
                strokeWidth="15" 
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                strokeLinecap="round"
              />
            </svg>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-2 mt-4">
          {fileTypes.map((type, index) => (
            <div key={index} className="flex items-center">
              <div className={`h-3 w-3 rounded-sm ${type.color} mr-2`}></div>
              <span className="text-sm text-gray-600">{type.type} ({type.percentage}%)</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
