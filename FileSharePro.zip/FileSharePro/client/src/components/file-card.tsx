import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileIcon, 
  DownloadIcon, 
  TrashIcon, 
  ShareIcon, 
  MoreHorizontalIcon 
} from "lucide-react";
import { formatBytes } from "@/lib/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

interface FileCardProps {
  file: {
    id: number;
    name: string;
    originalName: string;
    size: number;
    mimeType: string;
    createdAt: string;
    updatedAt: string;
  };
  onDelete?: (fileId: number) => void;
  onShare?: (file: any) => void;
}

export default function FileCard({ file, onDelete, onShare }: FileCardProps) {
  const fileType = file.mimeType.split('/')[1]?.toUpperCase() || 'FILE';
  const fileExtension = file.originalName.split('.').pop()?.toUpperCase() || fileType;
  
  // Determine icon background color based on file type
  const getBackgroundColor = () => {
    if (fileType.includes('PDF')) return 'bg-red-100 text-red-600';
    if (fileType.includes('WORD') || fileType.includes('DOC')) return 'bg-blue-100 text-blue-600';
    if (fileType.includes('EXCEL') || fileType.includes('XLS') || fileType.includes('SHEET')) return 'bg-green-100 text-green-600';
    if (fileType.includes('IMAGE') || fileType.includes('JPEG') || fileType.includes('PNG')) return 'bg-purple-100 text-purple-600';
    return 'bg-blue-100 text-blue-600';
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <div className={`flex-shrink-0 h-10 w-10 flex items-center justify-center rounded ${getBackgroundColor()}`}>
              <FileIcon className="h-5 w-5" />
            </div>
            <div className="ml-3">
              <div className="text-sm font-medium text-gray-900 truncate max-w-[200px]">{file.originalName}</div>
              <div className="text-xs text-gray-500">{formatBytes(file.size)} • {new Date(file.updatedAt).toLocaleDateString()}</div>
            </div>
          </div>
          
          <div className="flex items-center">
            <Button variant="ghost" size="icon" asChild className="h-8 w-8">
              <a href={`/api/files/${file.id}/download`} download>
                <DownloadIcon className="h-4 w-4" />
              </a>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontalIcon className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <a href={`/api/files/${file.id}/download`} download className="cursor-pointer">
                    <DownloadIcon className="h-4 w-4 mr-2" />
                    Download
                  </a>
                </DropdownMenuItem>
                {onShare && (
                  <DropdownMenuItem onClick={() => onShare(file)}>
                    <ShareIcon className="h-4 w-4 mr-2" />
                    Share
                  </DropdownMenuItem>
                )}
                {onDelete && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(file.id)}
                    className="text-red-600 focus:text-red-600">
                    <TrashIcon className="h-4 w-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
