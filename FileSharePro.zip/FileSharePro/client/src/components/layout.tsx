import { ReactNode, useState } from "react";
import Sidebar from "./sidebar";
import UserDropdown from "./user-dropdown";
import MobileNav from "./mobile-nav";
import { useAuth } from "@/hooks/useAuth";
import { CloudIcon, MenuIcon, Search as SearchIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import FileUploadModal from "./file-upload-modal";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [, navigate] = useLocation();

  // Redirect if not authenticated
  if (!isLoading && !isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="flex items-center justify-between px-4 py-3 lg:px-8">
          {/* Logo & Toggle Menu (Mobile) */}
          <div className="flex items-center">
            <button 
              className="lg:hidden mr-2 text-gray-500 hover:text-gray-700"
              onClick={toggleSidebar}
            >
              <MenuIcon className="h-6 w-6" />
            </button>
            <a href="#" className="flex items-center gap-2 text-primary" onClick={() => navigate("/dashboard")}>
              <CloudIcon className="h-6 w-6" />
              <span className="text-xl font-bold">FileHub</span>
            </a>
          </div>
          
          {/* Search Bar */}
          <div className="hidden md:block flex-grow max-w-xl mx-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search files and folders..."
                className="pl-10"
              />
              <span className="absolute left-3 top-2.5 text-gray-400">
                <SearchIcon className="h-4 w-4" />
              </span>
            </div>
          </div>
          
          {/* User Menu */}
          <UserDropdown user={user} />
        </div>
        
        {/* Mobile Search */}
        <div className="md:hidden px-4 pb-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search..."
              className="pl-10"
            />
            <span className="absolute left-3 top-2.5 text-gray-400">
              <SearchIcon className="h-4 w-4" />
            </span>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Desktop */}
        <Sidebar className="hidden lg:block" />
        
        {/* Sidebar - Mobile (controlled by state) */}
        {isSidebarOpen && (
          <div className="fixed inset-0 z-40 lg:hidden">
            {/* Backdrop */}
            <div 
              className="fixed inset-0 bg-gray-600 bg-opacity-75"
              onClick={toggleSidebar}
            ></div>
            
            {/* Sidebar */}
            <div className="relative flex flex-col w-80 max-w-xs h-full bg-white">
              <Sidebar />
            </div>
          </div>
        )}
        
        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 lg:p-8">
          {children}
        </main>
      </div>
      
      {/* Mobile Navigation */}
      <MobileNav onUploadClick={() => setIsUploadModalOpen(true)} />

      {/* File Upload Modal */}
      <FileUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)} 
      />
    </div>
  );
}
