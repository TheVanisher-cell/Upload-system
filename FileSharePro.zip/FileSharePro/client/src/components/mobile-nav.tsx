import { useLocation } from "wouter";
import { 
  LayoutDashboard, 
  FileIcon, 
  Share2, 
  Settings, 
  UploadCloud 
} from "lucide-react";

interface MobileNavProps {
  onUploadClick: () => void;
}

export default function MobileNav({ onUploadClick }: MobileNavProps) {
  const [location, navigate] = useLocation();

  const isActive = (path: string) => location === path;

  const navItems = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: <LayoutDashboard className="text-xl" />,
    },
    {
      name: "Files",
      path: "/files",
      icon: <FileIcon className="text-xl" />,
    },
    {
      name: "Upload",
      path: "#upload",
      icon: (
        <div className="bg-primary text-white p-3 rounded-full shadow-lg -mt-5">
          <UploadCloud className="text-xl" />
        </div>
      ),
      onClick: onUploadClick,
    },
    {
      name: "Shared",
      path: "/shared",
      icon: <Share2 className="text-xl" />,
    },
    {
      name: "Settings",
      path: "/settings",
      icon: <Settings className="text-xl" />,
    },
  ];

  return (
    <nav className="lg:hidden bg-white border-t border-gray-200 fixed bottom-0 left-0 right-0 z-10">
      <div className="flex justify-between px-4 py-3">
        {navItems.map((item) => (
          <button
            key={item.path}
            className={`flex flex-col items-center ${
              isActive(item.path) ? "text-primary" : "text-gray-500"
            }`}
            onClick={() => {
              if (item.onClick) {
                item.onClick();
              } else {
                navigate(item.path);
              }
            }}
          >
            {item.icon}
            <span className="text-xs mt-1">{item.name}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
