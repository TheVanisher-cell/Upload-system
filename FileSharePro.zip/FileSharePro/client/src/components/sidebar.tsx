import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  LayoutDashboard,
  FileIcon,
  Share2,
  Star,
  Clock,
  Trash2,
  Users,
  Settings,
  FileText,
  Shield
} from "lucide-react";
import { formatBytes } from "@/lib/utils";

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className = "" }: SidebarProps) {
  const { user, isAuthenticated } = useAuth();
  const [location, navigate] = useLocation();

  // Fetch storage stats
  const { data: storageStats } = useQuery({
    queryKey: ["/api/storage"],
    enabled: isAuthenticated,
  });
  
  const isAdmin = user?.role === "admin";
  const usedStorage = storageStats?.used || 0;
  const storageLimit = storageStats?.limit || 100 * 1024 * 1024; // Default to 100MB
  const storagePercentage = Math.min(100, Math.round((usedStorage / storageLimit) * 100));

  const navItems = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: <LayoutDashboard className="mr-3 h-5 w-5" />,
    },
    {
      name: "My Files",
      path: "/files",
      icon: <FileIcon className="mr-3 h-5 w-5" />,
    },
    {
      name: "Shared",
      path: "/shared",
      icon: <Share2 className="mr-3 h-5 w-5" />,
    },
    {
      name: "Starred",
      path: "/starred",
      icon: <Star className="mr-3 h-5 w-5" />,
    },
    {
      name: "Recent",
      path: "/recent",
      icon: <Clock className="mr-3 h-5 w-5" />,
    },
    {
      name: "Trash",
      path: "/trash",
      icon: <Trash2 className="mr-3 h-5 w-5" />,
    },
  ];

  const adminNavItems = [
    {
      name: "User Management",
      path: "/admin/users",
      icon: <Users className="mr-3 h-5 w-5" />,
    },
    {
      name: "System Settings",
      path: "/admin/settings",
      icon: <Settings className="mr-3 h-5 w-5" />,
    },
    {
      name: "Activity Logs",
      path: "/admin/logs",
      icon: <FileText className="mr-3 h-5 w-5" />,
    },
  ];

  return (
    <aside className={`w-64 bg-white border-r border-gray-200 overflow-y-auto ${className}`}>
      <div className="p-4">
        <nav className="space-y-1">
          {navItems.map((item) => (
            <Button
              key={item.path}
              variant="ghost"
              className={`w-full justify-start ${
                location === item.path
                  ? "bg-blue-50 text-primary"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
              onClick={() => navigate(item.path)}
            >
              {item.icon}
              <span>{item.name}</span>
            </Button>
          ))}
        </nav>

        <div className="border-t border-gray-200 my-4"></div>

        <div>
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Storage
          </h3>
          <div className="mt-2 px-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-700">{formatBytes(usedStorage)} used</span>
              <span className="text-gray-700">{formatBytes(storageLimit)}</span>
            </div>
            <Progress value={storagePercentage} className="h-2 mt-1" />
            <Button
              variant="link"
              className="mt-2 p-0 h-auto text-sm text-primary hover:text-blue-700"
            >
              Upgrade Storage
            </Button>
          </div>
        </div>

        {/* Admin Section (only visible for admins) */}
        {isAdmin && (
          <div className="border-t border-gray-200 my-4">
            <h3 className="mt-4 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center">
              <Shield className="h-3 w-3 mr-1" /> Admin
            </h3>
            <nav className="mt-2 space-y-1">
              {adminNavItems.map((item) => (
                <Button
                  key={item.path}
                  variant="ghost"
                  className={`w-full justify-start ${
                    location === item.path
                      ? "bg-blue-50 text-primary"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                  onClick={() => navigate(item.path)}
                >
                  {item.icon}
                  <span>{item.name}</span>
                </Button>
              ))}
            </nav>
          </div>
        )}
      </div>
    </aside>
  );
}
