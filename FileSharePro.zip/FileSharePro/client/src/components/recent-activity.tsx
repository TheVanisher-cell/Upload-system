import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  UploadCloud, 
  Download, 
  Trash2, 
  Share2, 
  Edit, 
  FileText 
} from "lucide-react";

interface Activity {
  id: number;
  userId: string;
  fileId: number | null;
  action: string;
  details: string;
  createdAt: string;
}

interface RecentActivityProps {
  activities: Activity[];
  isLoading?: boolean;
}

export default function RecentActivity({ activities, isLoading = false }: RecentActivityProps) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {[...Array(4)].map((_, index) => (
              <div key={index} className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-gray-200 animate-pulse"></div>
                <div className="ml-3 flex-1">
                  <div className="h-4 bg-gray-200 rounded animate-pulse w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded animate-pulse w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Helper to get icon based on activity action
  const getActivityIcon = (action: string) => {
    switch (action) {
      case "upload":
        return <UploadCloud className="text-primary" />;
      case "download":
        return <Download className="text-emerald-600" />;
      case "delete":
        return <Trash2 className="text-red-600" />;
      case "share":
      case "unshare":
        return <Share2 className="text-violet-600" />;
      case "edit":
        return <Edit className="text-amber-600" />;
      default:
        return <FileText className="text-gray-600" />;
    }
  };

  // Helper to get background color based on activity action
  const getActivityBackground = (action: string) => {
    switch (action) {
      case "upload":
        return "bg-blue-100";
      case "download":
        return "bg-emerald-100";
      case "delete":
        return "bg-red-100";
      case "share":
      case "unshare":
        return "bg-violet-100";
      case "edit":
        return "bg-amber-100";
      default:
        return "bg-gray-100";
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
        
        {activities.length > 0 ? (
          <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <span className={`flex h-8 w-8 items-center justify-center rounded-full ${getActivityBackground(activity.action)}`}>
                    {getActivityIcon(activity.action)}
                  </span>
                </div>
                <div className="ml-3 flex-1">
                  <div className="text-sm font-medium text-gray-900">
                    {activity.details || `You performed ${activity.action} action`}
                  </div>
                  <div className="text-sm text-gray-500">
                    {new Date(activity.createdAt).toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500 mb-2">No recent activity</p>
            <p className="text-sm text-gray-400">Upload or interact with files to see activity here</p>
          </div>
        )}
        
        {activities.length > 0 && (
          <Button variant="link" className="mt-4 px-0">
            View all activity
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
