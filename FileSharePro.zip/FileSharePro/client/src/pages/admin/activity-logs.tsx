import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { 
  UploadCloud, 
  Download, 
  Trash, 
  Share, 
  Activity
} from "lucide-react";

export default function ActivityLogs() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect if not authenticated
  if (!isLoading && !isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  // Fetch all activity logs
  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ["/api/admin/activities"],
    enabled: isAuthenticated,
  });

  // Check if user is an admin
  const isAdmin = user?.role === "admin";
  if (!isLoading && !isAdmin) {
    // Redirect non-admins
    window.location.href = "/dashboard";
    return null;
  }

  // Helper to get icon based on activity action
  const getActivityIcon = (action: string) => {
    switch (action) {
      case "upload":
        return <UploadCloud className="h-5 w-5 text-blue-500" />;
      case "download":
        return <Download className="h-5 w-5 text-green-500" />;
      case "delete":
        return <Trash className="h-5 w-5 text-red-500" />;
      case "share":
      case "unshare":
        return <Share className="h-5 w-5 text-purple-500" />;
      default:
        return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <Layout>
      <div>
        <h1 className="text-2xl font-bold mb-6">Activity Logs</h1>

        <Card>
          <CardContent className="pt-6">
            {isLoadingActivities ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, index) => (
                  <div key={index} className="h-16 bg-gray-100 animate-pulse rounded-lg"></div>
                ))}
              </div>
            ) : activities && activities.length > 0 ? (
              <div className="space-y-4">
                {activities.map((activity) => (
                  <div key={activity.id} className="flex items-start border-b border-gray-100 pb-4">
                    <div className="flex-shrink-0 mt-1">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100">
                        {getActivityIcon(activity.action)}
                      </span>
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-900">
                          User ID: {activity.userId}
                        </div>
                        <div className="text-sm text-gray-500">
                          {new Date(activity.createdAt).toLocaleString()}
                        </div>
                      </div>
                      <div className="text-sm text-gray-500 mt-1">
                        Action: <span className="font-medium capitalize">{activity.action}</span>
                      </div>
                      {activity.details && (
                        <div className="text-sm text-gray-700 mt-1">{activity.details}</div>
                      )}
                      {activity.fileId && (
                        <div className="text-sm text-gray-500 mt-1">File ID: {activity.fileId}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No activity logs found</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
