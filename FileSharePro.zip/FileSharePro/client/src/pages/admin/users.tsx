import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, User, Database } from "lucide-react";
import { formatBytes } from "@/lib/utils";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Users() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [storageLimitDialogOpen, setStorageLimitDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [storageLimit, setStorageLimit] = useState("");

  // Redirect if not authenticated
  if (!isLoading && !isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  // Fetch all users
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/admin/users"],
    enabled: isAuthenticated,
  });

  // Make admin mutation
  const makeAdminMutation = useMutation({
    mutationFn: async (userId: string) => {
      await apiRequest("POST", `/api/admin/user/${userId}/make-admin`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User updated",
        description: "User has been made an admin successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update user role",
        variant: "destructive",
      });
      console.error("Error making user admin:", error);
    },
  });

  // Update storage limit mutation
  const updateStorageLimitMutation = useMutation({
    mutationFn: async ({ userId, limit }: { userId: string; limit: number }) => {
      await apiRequest("POST", `/api/admin/user/${userId}/storage-limit`, { storageLimit: limit });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setStorageLimitDialogOpen(false);
      setStorageLimit("");
      toast({
        title: "Storage limit updated",
        description: "User's storage limit has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update storage limit",
        variant: "destructive",
      });
      console.error("Error updating storage limit:", error);
    },
  });

  const handleMakeAdmin = (userId: string) => {
    if (confirm("Are you sure you want to make this user an admin?")) {
      makeAdminMutation.mutate(userId);
    }
  };

  const handleUpdateStorageLimit = (selectedUser: any) => {
    setSelectedUser(selectedUser);
    setStorageLimit((selectedUser.storageLimit / (1024 * 1024)).toString()); // Convert to MB
    setStorageLimitDialogOpen(true);
  };

  const confirmUpdateStorageLimit = () => {
    if (!selectedUser || !storageLimit) return;
    
    const limitInBytes = parseFloat(storageLimit) * 1024 * 1024; // Convert MB to bytes
    
    updateStorageLimitMutation.mutate({
      userId: selectedUser.id,
      limit: limitInBytes,
    });
  };

  // Check if user is an admin
  const isAdmin = user?.role === "admin";
  if (!isLoading && !isAdmin) {
    // Redirect non-admins
    window.location.href = "/dashboard";
    return null;
  }

  return (
    <Layout>
      <div>
        <h1 className="text-2xl font-bold mb-6">User Management</h1>

        <Card>
          <CardContent className="pt-6">
            {isLoadingUsers ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, index) => (
                  <div key={index} className="h-16 bg-gray-100 animate-pulse rounded-lg"></div>
                ))}
              </div>
            ) : users && users.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Storage Used</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Storage Limit</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {users.map((user) => (
                      <tr key={user.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              {user.profileImageUrl ? (
                                <img
                                  src={user.profileImageUrl}
                                  alt={user.firstName || "User"}
                                  className="h-10 w-10 rounded-full object-cover"
                                />
                              ) : (
                                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                  <User className="h-6 w-6 text-gray-500" />
                                </div>
                              )}
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {user.firstName && user.lastName
                                  ? `${user.firstName} ${user.lastName}`
                                  : "User " + user.id.substring(0, 8)}
                              </div>
                              <div className="text-sm text-gray-500">ID: {user.id}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.email || "No email"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            user.role === "admin" 
                              ? "bg-purple-100 text-purple-800" 
                              : "bg-green-100 text-green-800"
                          }`}>
                            {user.role || "user"}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatBytes(user.storageUsed)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatBytes(user.storageLimit)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          {user.role !== "admin" && (
                            <Button variant="outline" size="sm" onClick={() => handleMakeAdmin(user.id)} className="mr-2">
                              <Shield className="h-4 w-4 mr-1" />
                              Make Admin
                            </Button>
                          )}
                          
                          <Button variant="outline" size="sm" onClick={() => handleUpdateStorageLimit(user)}>
                            <Database className="h-4 w-4 mr-1" />
                            Set Limit
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No users found</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Storage Limit Dialog */}
      <Dialog open={storageLimitDialogOpen} onOpenChange={setStorageLimitDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Storage Limit</DialogTitle>
            <DialogDescription>
              Set a new storage limit for this user in MB.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="storage-limit">Storage Limit (MB)</Label>
            <Input
              id="storage-limit"
              type="number"
              value={storageLimit}
              onChange={(e) => setStorageLimit(e.target.value)}
              placeholder="Enter limit in MB"
              className="mt-1"
            />
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setStorageLimitDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmUpdateStorageLimit} disabled={!storageLimit}>
              Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
