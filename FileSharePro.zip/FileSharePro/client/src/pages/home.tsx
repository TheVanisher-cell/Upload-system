import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { CloudIcon, UploadCloudIcon, HardDriveIcon, LockIcon } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleStartNow = () => {
    if (isAuthenticated) {
      navigate("/dashboard");
    } else {
      window.location.href = "/api/login";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header/Navigation */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2 text-primary">
            <CloudIcon className="h-8 w-8" />
            <span className="text-2xl font-bold">FileHub</span>
          </div>
          
          <div className="flex items-center gap-4">
            {isLoading ? (
              <div className="h-10 w-24 bg-gray-200 animate-pulse rounded-lg"></div>
            ) : isAuthenticated ? (
              <Button onClick={() => navigate("/dashboard")}>
                Go to Dashboard
              </Button>
            ) : (
              <Button onClick={handleLogin}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Secure Cloud Storage Solution
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-10">
            Store, share, and access your files from anywhere with our secure cloud storage platform.
          </p>
          <Button size="lg" onClick={handleStartNow} className="text-lg px-8 py-6">
            Start Now
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 rounded-lg bg-blue-100 text-primary mb-4">
                    <UploadCloudIcon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Easy File Upload</h3>
                  <p className="text-gray-600">
                    Upload your files with a simple drag and drop interface. Store all your important documents securely.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 rounded-lg bg-violet-100 text-violet-600 mb-4">
                    <HardDriveIcon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Ample Storage</h3>
                  <p className="text-gray-600">
                    Get generous storage space for all your files with options to upgrade as your needs grow.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 rounded-lg bg-emerald-100 text-emerald-600 mb-4">
                    <LockIcon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Enhanced Security</h3>
                  <p className="text-gray-600">
                    Your files are protected with enterprise-grade security ensuring your data remains private and secure.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <CloudIcon className="h-6 w-6" />
              <span className="text-xl font-bold">FileHub</span>
            </div>
            
            <div className="text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} FileHub. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
