import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import Layout from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileIcon, FolderIcon, ShareIcon, UploadCloudIcon } from "lucide-react";
import StorageChart from "@/components/storage-chart";
import RecentActivity from "@/components/recent-activity";
import { useState } from "react";
import FileUploadModal from "@/components/file-upload-modal";
import { formatBytes } from "@/lib/utils";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Redirect if not authenticated
  if (!isLoading && !isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  // Fetch storage stats
  const { data: storageStats, isLoading: isLoadingStorage } = useQuery({
    queryKey: ["/api/storage"],
    enabled: isAuthenticated,
  });

  // Fetch recent files
  const { data: recentFiles, isLoading: isLoadingRecentFiles } = useQuery({
    queryKey: ["/api/files/recent"],
    enabled: isAuthenticated,
  });

  // Fetch recent activities
  const { data: recentActivities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ["/api/activities"],
    enabled: isAuthenticated,
  });

  // Fetch all files for counting
  const { data: allFiles } = useQuery({
    queryKey: ["/api/files"],
    enabled: isAuthenticated,
  });

  // Fetch shared files for counting
  const { data: sharedFiles } = useQuery({
    queryKey: ["/api/files/shared"],
    enabled: isAuthenticated,
  });

  // Handle upload modal
  const openUploadModal = () => setIsUploadModalOpen(true);
  const closeUploadModal = () => setIsUploadModalOpen(false);

  return (
    <Layout>
      <div>
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-100 text-primary">
                  <FileIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <h3 className="text-gray-500 text-sm font-medium">Total Files</h3>
                  <p className="text-2xl font-semibold">{allFiles?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-violet-100 text-secondary">
                  <FolderIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <h3 className="text-gray-500 text-sm font-medium">Folders</h3>
                  <p className="text-2xl font-semibold">0</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-emerald-100 text-emerald-600">
                  <ShareIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <h3 className="text-gray-500 text-sm font-medium">Shared Files</h3>
                  <p className="text-2xl font-semibold">{sharedFiles?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-amber-100 text-amber-600">
                  <UploadCloudIcon className="h-6 w-6" />
                </div>
                <div className="ml-4">
                  <h3 className="text-gray-500 text-sm font-medium">Recent Uploads</h3>
                  <p className="text-2xl font-semibold">{recentFiles?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Storage Usage Chart & Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <StorageChart 
            used={storageStats?.used || 0} 
            limit={storageStats?.limit || 100 * 1024 * 1024} 
            isLoading={isLoadingStorage} 
          />
          
          <RecentActivity 
            activities={recentActivities || []} 
            isLoading={isLoadingActivities} 
          />
        </div>

        {/* Recent Files */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Recent Files</h2>
              <Button variant="link" onClick={() => navigate("/files")}>View all</Button>
            </div>

            {isLoadingRecentFiles ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, index) => (
                  <div key={index} className="h-16 bg-gray-100 animate-pulse rounded-lg"></div>
                ))}
              </div>
            ) : recentFiles && recentFiles.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Modified</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {recentFiles.map((file) => (
                      <tr key={file.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center rounded bg-blue-100 text-primary">
                              <FileIcon className="h-5 w-5" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{file.originalName}</div>
                              <div className="text-sm text-gray-500">Uploaded {new Date(file.createdAt).toLocaleDateString()}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatBytes(file.size)}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                            {file.mimeType.split('/')[1]?.toUpperCase() || 'FILE'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(file.updatedAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button variant="ghost" size="sm" asChild>
                            <a href={`/api/files/${file.id}/download`} download>Download</a>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No files uploaded yet</p>
                <Button onClick={openUploadModal}>Upload Files</Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* File Upload Modal */}
      <FileUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={closeUploadModal} 
      />
    </Layout>
  );
}
